__version__="4.9.1"
__copyright__="Copyright (c) 2001 - 2025 The SCons Foundation"
__developer__="bdbaddog"
__date__="Fri, 28 Mar 2025 15:25:00 -0700"
__buildsys__="M1Dog2021"
__revision__="dfd6b7e45985eb73462d2efa878651c92745099c"
__build__="dfd6b7e45985eb73462d2efa878651c92745099c"
# make sure compatibility is always in place
import SCons.compat  # noqa